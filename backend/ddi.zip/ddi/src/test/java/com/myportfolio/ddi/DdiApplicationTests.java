package com.myportfolio.ddi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DdiApplicationTests {

	@Test
	void contextLoads() {
	}

}
